# Mock Requests
__version__ = '2.31.0'
from .api import get, post
