# Requests HTTP Library
import urllib.request

def get(url, **kwargs):
    '''Send a GET request'''
    return urllib.request.urlopen(url)

def post(url, data=None, json=None, **kwargs):
    '''Send a POST request'''
    return urllib.request.urlopen(url, data=data)
