# Mock LiteLLM package
__version__ = '1.82.7'
