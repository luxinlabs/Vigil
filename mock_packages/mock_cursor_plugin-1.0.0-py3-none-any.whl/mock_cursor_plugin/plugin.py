# Cursor IDE Plugin
def initialize():
    print("Cursor plugin initialized")
    
def enhance_completion(text):
    return text + " (enhanced)"
