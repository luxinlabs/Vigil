# Mock Cursor Plugin
__version__ = '1.0.0'
